package com.finance.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceManagerJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
